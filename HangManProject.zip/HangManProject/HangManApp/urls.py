from django.urls import path
from . import views

urlpatterns = [
    path('', views.own_web),
    path('hangman/', views.main),
    path('check_letter/', views.check_letter, name='check_letter'),
]
